<?php

namespace EnseignantBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EnseignantBundle extends Bundle
{
}
